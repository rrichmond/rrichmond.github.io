## MFE Programming Workshop Week 3 Lab Solution
## This one uses data.table instead of dplyr
## Robert Richmond
library(lubridate)
library(data.table)
library(reshape2)
library(ggplot2)
## need zoo for as.yearmon
library(zoo)

## read in the returns to the 25 fama-french portfolios
ffports <- fread("FFports.csv")

## clean up the Dates
ffports[,Date:=ymd(paste(ffports$Date,"01",sep=""))]
## convert the Date to month using zoo:::as.yearmon
ffports[,Date:=as.yearmon(Date)]

## convert to long form using melt
ffportslong <- melt(ffports,id.vars="Date",variable.name="portfolio",value.name="ret")

## read in the risk factors
## and clean up the Dates
ff <- fread("FFfactors.csv")
## lower case to match with the portfolios
setnames(ff,"Date","Date")
ff[,Date:=as.yearmon(ymd(paste(Date,"01",sep="")))]

## merge everything together
all <- merge(ffportslong,ff,all.x=TRUE,by="Date")

## calculate excess returns
all[,excess:=ret - RF]

## get a subset
start <- as.yearmon(ymd("1963-01-01"))
end <- as.yearmon(ymd("2013-12-31"))
subs <- all[Date <= end & Date >= start,]

## get a time series beta and an average excess return
## note that the j argument in data.table can be an express
## as long as it returns a list (in this case a data.frame)
## then data.table will make the output into a data.table
portvals <- subs[,
{
    mymod <- lm(excess ~ MktRF)
    coefs <- coef(mymod)
    out <- data.frame(intercept=coefs[1],
                      MktRF=coefs[2],
                      meanexcess=mean(excess,na.rm = TRUE))
    out
},
by=portfolio]

## I'm going to use ggplot, but you could obviously just plot the
## two data series with plot. You may need to install ggplot2
## for this to work
ggplot(portvals) + geom_text(aes(MktRF,meanexcess,label=portfolio))

## do a similar thing, but for the FF model
## also get the factor means over the same sample period
## for each portfolio
portvalsff <- subs[,
{
    mymod <- lm(excess ~ MktRF + SMB + HML)
    out <- data.frame(t(coef(mymod)),
                      meanexcess=mean(excess,na.rm = TRUE),
                      meanMktRF=mean(MktRF),
                      meanHML=mean(HML),                      
                      meanSMB=mean(SMB))
    out
},
by=portfolio]

## now get the predicted value
portvalsff[,predval:=MktRF*meanMktRF+HML*meanHML+SMB*meanSMB]

portvalsff

 ## make the plot
ggplot(portvalsff) + geom_text(aes(predval,meanexcess,label=portfolio))
